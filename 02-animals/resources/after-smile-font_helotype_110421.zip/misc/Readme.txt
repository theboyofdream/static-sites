Hello,

Thank for downloading After Smile.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
https://www.creativefabrica.com/product/after-smile/ref/236066/

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
yudisetiawan58@hotmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/yuriko774
 
Please visit our store for more amazing fonts : 
https://www.creativefabrica.com/designer/helotype/ref/236066/

Follow our instagram for update : @helotype

Thank you.

-------------------